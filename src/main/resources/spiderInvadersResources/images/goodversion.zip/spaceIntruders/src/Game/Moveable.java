
package Game;

/**
 *
 * @author Spartan Tech
 */
public interface Moveable {
    
    public void move();
    
}
