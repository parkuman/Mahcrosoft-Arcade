
package Game;

import java.awt.Graphics;

/**
 *
 * @author Spartan Tech
 */
public interface Drawable {
    
    public void draw(Graphics g);
    
}
